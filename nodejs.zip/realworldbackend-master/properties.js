module.exports = {
    env:{
        jwtTokenKey:"nodejsRestApiGirish"
    }
}